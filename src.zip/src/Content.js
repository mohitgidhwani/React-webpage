import React, { useEffect, useRef, useState } from 'react'
import './App.css'
import { useParams } from 'react-router-dom';
import { DateRange } from 'react-date-range';


function Content({fun}) {

  const [adult, setAdult] = useState(1);
  const [child, setChild] = useState(1);
  const [room, setRoom] = useState(1);

  const [hide, setHide] = useState(false)

  const inner = () => {

    if (hide) {
      setHide(false)
    }
    else {
      setHide(true)
    }


  }

  // const { id } = useParams()



 

  // const [hotel, setHotel] = useState([])

  // const [showCal, setShowCal] = useState(false)
  const [hotels, setHotels] = useState([])
  const [filteredHotels, setFilteredHotels] = useState([])
  const [locationInput, setLocationInput] = useState('')

  useEffect(() => {
    fetch(`http://localhost:5000/hotel`)
      .then((res) => { return res.json() })
      .then((data) => {
        setHotels(data)
        setFilteredHotels(data)
      })
  }, [])


  // const handleSearchChange = (e) => {

  //   const value = e.target.value
  //   setLocationInput(value)

  //   const filtered =  hotels.filter((hotel) =>
  //     hotel.location.toLowerCase().includes(value.toLowerCase())
  //   ) 

  //   setFilteredHotels(filtered);
  // }

  // const findhotel = (e)=>{
  //      const value = e.target.value

  //      setLocationInput(value)

  //      const filtered = hotels.filter((hotel)=>(
  //       hotel.location.toLowerCase().includes(value.toLowerCase())
  //       )
  //      )


  //     setFilteredHotels(filtered)
       

    
  // }


  // const [state, setState] = useState([
  //   {
  //     startDate: new Date(),
  //     endDate: null,
  //     key: 'selection'
  //   }
  // ]);
  return (
    <>
      <div className='container-fluid icons'>
        <div className='container pt-4 pb-5'>
          <ul className=' options list-unstyled gap-5  text-white'>
            <li className='border p-3 rounded-5'><i className="fa-solid fa-bed"></i> Stays</li>
            <li className=' p-3 rounded-5'><i className="fa-solid fa-plane"></i> Flights</li>
            <li className=' p-3 rounded-5'><i className="fa-solid fa-earth-americas"></i> Flight + Hotel</li>
            <li className=' p-3 rounded-5'><i className="fa-solid fa-car"></i> Car rentals</li>
            <li className=' p-3 rounded-5'><i className="fa-solid fa-location-dot"></i> Attractions</li>
            <li className=' p-3 rounded-5'><i className="fa-solid fa-taxi"></i> Airport Taxis</li>
          </ul>
        </div>
        <div className='container text-start lh-1'>
          <h1 className='fw-bold text-white fs-1'>Find Your Next Stay</h1>
          <h3 className='text-white'>Search Low prices on hotel,homes and much more...</h3>
        </div>

        <div className='input-field container mt-5 '>
          <div className='inner-container   justify-content-center gap-1'>
            <input className='inp'
              // value={locationInput}
              // onChange={handleSearchChange}
              onChange={fun}
              placeholder='Where are you Going?'
              type='text'>

            </input>
            <div>
              <input className='inp' type='date' 
              // onClick={() => { setShowCal(true) }}
              ></input>
              {/* {showCal ? <DateRange
                editableDateInputs={true}
                onChange={item => setState([item.selection])}
                moveRangeOnFirstSelection={false}
                ranges={state}
              /> : null} */}
            </div>



            <div className='outer' >
              <li className="inp  nav-item nav-item1 dropdown" >
                <i className="fa-regular fa-user"></i> {adult} adults · {child} children · {room} room  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<button className='border border-0' onClick={inner}><i className="fa-solid fa-arrow-down"></i></button>
              </li>
              <div className='inner' style={{ display: (hide) ? "block" : "none" }} >
                <div className='flex '>
                  <div>
                    <div><label>Adults</label></div>
                    <div className='my-4'><label>children</label></div>
                    <div><label>Rooms</label></div>
                  </div>
                  <div>
                    <div>
                      <span className='count'><button onClick={() => { setAdult(adult - 1) }}>-</button> <span className='num'>{adult}</span> <button onClick={() => { setAdult(adult + 1) }}>+</button></span>
                    </div>
                    <div className='my-4'>
                      <span className='count '><button onClick={() => { setChild(child - 1) }}>-</button> <span className='num'>{child}</span> <button onClick={() => { setChild(child + 1) }}>+</button></span>
                    </div>
                    <div>
                      <span className='count'><button onClick={() => { setRoom(room - 1) }}>-</button> <span className='num'>{room}</span> <button onClick={() => { setRoom(room + 1) }}>+</button></span>
                    </div>
                  </div>
                </div>

              </div>
            </div>

            <input className='inp-btn' type='submit' value={'Search'}></input>
          </div>

        </div>
      </div>

      <div className='container' >
        <div className='row'>
          {/* {filteredHotels.map((hotel) => (
            <div className="cards col-md-3 mb-3" key={hotel.id}>
              <div className="card">
                <img src={hotel.img} className="card-img-top" alt={hotel.name} />
                <div className="card-body">
                  <h5 className="card-title">{hotel.name}</h5>
                  <p className="card-text">{hotel.location}</p>
                  <span>Rating: {hotel.rating}</span>
                </div>
              </div>
            </div>
          ))
          } */}

          {/* {filteredHotels.map((v)=>{
            return(
              <>
               <div  className='cards col-md-3'>
                  <div className="card" >
                    {<img src={v.img} className="card-img-top"  />}
                    <div className="card-body text-start ">
                      <h5 className="card-title ">{v.name}</h5>
                      <p className="card-text">{v.location}</p>
                      <span className='rating'>{v.rating}</span> <span>{v.rev}</span>

                    </div>
                  </div>
                </div>
              </>
            )
          })} */}
          {/* { hotel.map((v) => (
              <>
                <div  className='cards col'>
                  <div className="card" >
                    {<img src={v.img} className="card-img-top"  />}
                    <div className="card-body text-start ">
                      <h5 className="card-title ">{v.name}</h5>
                      <p className="card-text">{v.location}</p>
                      <span className='rating'>{v.rating}</span> <span>{v.rev}</span>

                    </div>
                  </div>
                </div>
              </>
            )
          )} */}
        </div>

      </div>
    </>
  )
}

export default Content