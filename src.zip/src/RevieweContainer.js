import React from 'react'
import './App.css'

function RevieweContainer() {
  return (
  <>
    <div className='reviews-container'>
          <label>New</label>
          <h1>Recent Reviews</h1>
          <div className='row-rev'>
            <div className='col-rev'>
                <div className='point'>9.3</div>
                <img src='https://themewagon.github.io/game-warrior/img/review/1.jpg'></img>
                <h3>Assasin’’s Creed</h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipisc ing ipsum dolor sit ame.</p>
            </div>
            <div className='col-rev'>
                <div className='point point2'>9.5</div>
                <img src='https://themewagon.github.io/game-warrior/img/review/2.jpg'></img>
                <h3>Doom</h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipisc ing ipsum dolor sit ame.</p>
            </div>
            <div className='col-rev'>
                <div className='point point3'>9.1</div>
                <img src='https://themewagon.github.io/game-warrior/img/review/3.jpg'></img>
                <h3>Overwatch</h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipisc ing ipsum dolor sit ame.</p>
            </div>
            <div className='col-rev'>
                <div className='point point4'>9.7</div>
                <img src='https://themewagon.github.io/game-warrior/img/review/4.jpg'></img>
                <h3>GTA</h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipisc ing ipsum dolor sit ame.</p>
            </div>
          </div>
    </div>
  </>
  )
}

export default RevieweContainer