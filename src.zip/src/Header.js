import React from 'react'
import './App.css'

function Header() {
    return (
        <>
            <nav className="navbar navbar-expand-lg pt-4">
                <div className="container">
                    <a className="navbar-brand fw-bold " href="#">Booking.Com</a>
                    <button className="navbar-toggler  border " type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span className="navbar-toggler-icon" />
                    </button>
                    <div className="collapse navbar-collapse " id="navbarSupportedContent">
                        <ul className="navbar-nav ms-auto  mb-lg-0">
                            <li className="nav-item">
                                <a className="nav-link active fw-bold text-white" aria-current="page" href="#">INR</a>
                            </li>
                            <li className="nav-item">
                                <a className="nav-link fw-bold" href="#">Country</a>
                            </li>
                            <li className="nav-item ">
                                <a className="nav-link fw-bold" href="#" role="button" aria-expanded="false">
                                    ?
                                </a>
                               
                            </li>
                            <li className="nav-item">
                                <a className="nav-link fw-bold" aria-disabled="true">List Your Property</a>
                            </li>
                        </ul>
                        <form className="d-flex justify-content-center" role="search">
                            <button className="btn bg-white  fw-bold mx-3" type="submit">Register</button>
                            <button className="btn bg-white fw-bold" type="submit">Sign in</button>
                        </form>
                    </div>
                </div>
            </nav>

        </>
    )
}

export default Header