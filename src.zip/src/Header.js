import './App.css'

export default function Header() {
    return (
        <>

            <nav className='navbar'>
                <div className='nav-logo'>
                    <img src='https://themewagon.github.io/game-warrior/img/logo.png'></img>
                </div>
                <div className='list'>
                    <ul>
                        <li><a href=''>Home</a></li>
                        <li><a href=''>Games</a></li>
                        <li><a href=''>Blog</a></li>
                        <li><a href=''>Forums</a></li>
                        <li><a href=''>Contact</a></li>
                    </ul>
                </div>
                <div>
                    <button className='login-btn'>Login/Register</button>
                   
                </div>
                <div>
                <button className='mobile-menu-btn'><i class="fa-solid fa-bars"></i></button>
                </div>
            </nav>
        </>
    )
}