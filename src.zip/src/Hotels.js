import React, { useEffect, useState } from 'react'
import { Link, Outlet, useParams } from 'react-router-dom'

function Hotels({ filt, hook }) {

 

    return (
        <>


 

            <div className='container'>
                <div className='row'>


                    {hook.map((v) => {
                        return (
                            <>
                                <Link to={`./view/${v.id}`} className="col-md-3 text-decoration-none" style={{ textDecoration: 'none' }}>
                                    <div className='cards' key={v.id}>

                                        <div className="card">
                                            <img src={v.img} className="card-img-top" alt={v.name} />
                                            <div className="card-body text-start">
                                                <h5 className="card-title">{v.name}</h5>
                                                <p className="card-text">{v.location}</p>
                                                <span className="rating">{v.rating}</span> <span>{v.rev}</span>
                                            </div>
                                        </div>

                                    </div>
                                </Link>

                            </>
                        )
                    })}
                </div>

            </div>
        </>
    )
}
export default Hotels