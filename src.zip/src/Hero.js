export default function Hero() {

    function change1() {
        const wallpaper = document.querySelector('section');
        const herotext = document.getElementById('h1');


        wallpaper.style.background = `url(https://themewagon.github.io/game-warrior/img/slider-1.jpg)`
         wallpaper.style.backgroundPosition = 'center'
        wallpaper.style.backgroundSize = 'cover'
         herotext.innerHTML = 'The Best <span>Games</span> Out There'
         
    }

    function change2() {
        const wallpaper = document.querySelector('section');
        const herotext = document.getElementById('h1');



        wallpaper.style.background = `url(https://themewagon.github.io/game-warrior/img/slider-2.jpg)`
        wallpaper.style.backgroundPosition = 'center'
        wallpaper.style.backgroundSize = 'cover'
       
        herotext.innerHTML = 'Find Your Favourite <span>Game</span> '
        
    }
    return (
        <>
            <section>
                <div className="hero" id="hero-sec">
                    <h1 id="h1">The Best <span>Games</span> Out There</h1>
                    <p>
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec malesuada <br></br>
                        lorem maximus mauris scelerisque, at rutrum nulla dictum. Ut ac ligula sapien.<br></br>
                        Suspendisse cursus faucibus finibus.
                    </p>
                    <button className="hero-btn">Read More</button>
                </div>
                <div className="theme-btn">
                    <div className="sel-btn" onClick={change1}>01.</div>
                    <div className="sel-btn" onClick={change2}>02.</div>
                </div>
            </section>
            <article>
                <div className="latest">
                    <span>Letest News</span>
                </div>
                <div className="news">

                    <div className="move-text">
                        <span>New</span>Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                        <span>STRATEGY</span>Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                        <span>RACING</span>Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                    </div>

                </div>
            </article>

        </>
    )
}