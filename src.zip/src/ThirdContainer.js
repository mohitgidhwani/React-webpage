import React from 'react'

function ThirdContainer() {
    return (
        <>
            <div className='third-container'>

                <div className='tourna1'>
                <span className='tournamnet tournamnet-anounce'>TOURNAMENT</span>
                    <span className='tournamnet'>PREMIUM TOURNAMENT</span>
                    <div>
                        <img src='https://themewagon.github.io/game-warrior/img/tournament/1.jpg'></img>
                    </div>
                    <div className='tourna-info'>
                        <h2>World of WarCraft</h2>

                        <p>Tournament Beggins: <span>June 20, 2018</span></p>
                        <p>Tounament Ends: <span>July 01, 2018</span></p>
                        <p>Participants: <span>10 teams</span></p>
                        <p>Tournament Author: <span>Admin</span></p>
                        <br></br>
                        <br></br>
                        <p> <label>Prize : </label> 1st place $2000, 2nd place: $1000, 3rd place: $500</p>
                    </div>
                </div>
                <div className='tourna1'>
                {/* <span className='tournamnet tournamnet-anounce'>TOURNAMENT</span> */}
                    <span className='tournamnet'>PREMIUM TOURNAMENT</span>
                    <div>
                        <img src='https://themewagon.github.io/game-warrior/img/tournament/2.jpg'></img>
                    </div>
                    <div className='tourna-info'>
                        <h2>DOOM</h2>

                        <p>Tournament Beggins: <span>June 20, 2018</span></p>
                        <p>Tounament Ends: <span>July 01, 2018</span></p>
                        <p>Participants: <span>10 teams</span></p>
                        <p>Tournament Author: <span>Admin</span></p>
                        <br></br>
                        <br></br>
                        <p> <label>Prize : </label> 1st place $2000, 2nd place: $1000, 3rd place: $500</p>
                    </div>
                </div>
                <div className='tourna2'></div>
            </div>
        </>
    )
}

export default ThirdContainer