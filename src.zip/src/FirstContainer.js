import './App.css'
export default function FirstContainer() {
    return (
        <>
            <div className="container1">
                <div className="row">
                    <div className="col">
                        <div className="card">
                            <div className='inner-card'>
                                <h4>New</h4>
                                <br></br>
                                <a href=''>Suspendisse ut justo
                                    <br></br>
                                    tem por, rutrum</a>
                                <p>Lorem ipsum dolor sit amet,
                                    <br></br>
                                    consectetur adipiscing elit.</p>
                                <span>3 Comments</span>
                            </div>
                        </div>
                        <div className="card card1">
                            <div className='inner-card'>
                                <h4>New</h4>
                                <br></br>
                                <a href=''>Suspendisse ut justo
                                    <br></br>
                                    tem por, rutrum</a>
                                <p>Lorem ipsum dolor sit amet,
                                    <br></br>
                                    consectetur adipiscing elit.</p>
                                <span>3 Comments</span>
                            </div>
                        </div>
                        <div className="card card2">
                            <div className='inner-card'>
                                <h4>New</h4>
                                <br></br>
                                <a href=''>Suspendisse ut justo
                                    <br></br>
                                    tem por, rutrum</a>
                                <p>Lorem ipsum dolor sit amet,
                                    <br></br>
                                    consectetur adipiscing elit.</p>
                                <span>3 Comments</span>
                            </div>
                        </div>
                        <div className="card card3">

                            <div className='inner-card'>
                                <h4>New</h4>
                                <br></br>
                                <a href=''>Suspendisse ut justo
                                    <br></br>
                                    tem por, rutrum</a>
                                <p>Lorem ipsum dolor sit amet,
                                    <br></br>
                                    consectetur adipiscing elit.</p>
                                <span>3 Comments</span>
                            </div>

                        </div>
                    </div>
                </div>
            </div>

        </>
    )
}