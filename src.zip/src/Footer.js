import React from 'react'
import './App.css'
function Footer() {
  return (
    <>
      <footer>
        <div className='footer-container'>
          <div className='footer-row'>
            <div className='footer-col'>
              <img className='logo-img-footer' src='https://themewagon.github.io/game-warrior/img/logo.png'></img>
              <p>Lorem ipsum dolor sit amet, consectetur
                adipisc ing ipsum dolor sit ame.</p>
              <img className='anime-logo' src='https://themewagon.github.io/game-warrior/img/footer-top-bg.png'></img>
              <img src=''></img>
            </div>
            <div className='footer-col footer-col2'>
              <h2>Latest Posts</h2>
              <div className='games-post'>
                <div>
                  <img src='https://themewagon.github.io/game-warrior/img/latest-blog/1.jpg'></img>
                </div>
                <div>
                  <h5>June 21,2018</h5>
                  <p>Lorem ipsum dolor sit amet, consectetur adipisc ing ipsum</p>
                  <span>By Admin</span>
                </div>
              </div>
              <div className='games-post'>
                <div>
                  <img src='https://themewagon.github.io/game-warrior/img/latest-blog/2.jpg'></img>
                </div>
                <div>
                  <h5>June 21,2018</h5>
                  <p>Lorem ipsum dolor sit amet, consectetur adipisc ing ipsum</p>
                  <span>By Admin</span>
                </div>
              </div>
              <div className='games-post'>
                <div>
                  <img src='https://themewagon.github.io/game-warrior/img/latest-blog/3.jpg'></img>
                </div>
                <div>
                  <h5>June 21,2018</h5>
                  <p>Lorem ipsum dolor sit amet, consectetur adipisc ing ipsum</p>
                  <span>By Admin</span>
                </div>
              </div>
            </div>
            <div className='footer-col footer-col2'>
              <h2>Top Comments</h2>
              <div className='games-post'>
                <div>
                  <img className='person' src='https://themewagon.github.io/game-warrior/img/authors/1.jpg'></img>
                </div>
                <div>
                  <h5>James Smith</h5>
                  <p>Lorem ipsum dolor sit amet, consectetur adipisc ing ipsum</p>
                  <span>June 21,2018</span>
                </div>
              </div>
              <div className='games-post'>
                <div>
                  <img className='person' src='https://themewagon.github.io/game-warrior/img/authors/2.jpg'></img>
                </div>
                <div>
                  <h5>James Smith</h5>
                  <p>Lorem ipsum dolor sit amet, consectetur adipisc ing ipsum</p>
                  <span>June 21,2018</span>
                </div>
              </div>
              <div className='games-post'>
                <div>
                  <img className='person' src='https://themewagon.github.io/game-warrior/img/authors/3.jpg'></img>
                </div>
                <div>
                  <h5>James Smith</h5>
                  <p>Lorem ipsum dolor sit amet, consectetur adipisc ing ipsum</p>
                  <span>June 21,2018</span>
                </div>
              </div>
            </div>
          </div>
          <div className='inner-footer'>
            <div>
              <p>Copyright ©2025 All rights reserved | This template is made with  by Colorlib</p>
            </div>
            <div className='footer-list'>
              <ul>
                <li><a href=''>Home</a></li>
                <li><a href=''>Games</a></li>
                <li><a href=''>Blog</a></li>
                <li><a href=''>Forums</a></li>
                <li><a href=''>Contact</a></li>
              </ul>
            </div>
          </div>
        </div>
      </footer>
    </>
  )
}

export default Footer