import React, { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'

function View() {
  const [view, setView] = useState([])
  // const [photo,setPhoto] = useState([])


  const { id } = useParams()

  // console.log(id)

  useEffect(() => {
    fetch(`http://localhost:5000/hotel/${id}`)
      .then((res) => { return res.json() })
      .then((data) => {
        setView(data)

      })
  }, [])



  return (
    <>
    


      <div className='container mt-5'>
        <div className='container  text-start'>
          <h3>{view.name}</h3>
          <p>{view.location}</p>
           

           <div className='gallery'>
               <div className='main-left'>
                <img src={view.img1}></img>
               </div>
               <div className='main-right'>
                   <div className='top'> <img src={view.img2}></img></div>
                   <div className='bottom'> <img src={view.img3}></img></div>
               </div>
              
               <div className='side-data text-end'>
                  <div className='border rounded'>
                  <h5 className='fw-normal'>{view.rev}</h5>
                  <span className=''>{view.rating}</span>
                  </div>
                   <div className='border border-dark-50 rounded p-3 '>
                       <h6>Free Wifi <span className='border p-2 rounded bg-info'>8.5</span> </h6> 
                   </div>
                   <div>
                  <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d146418.55627655226!2d72.4044879972656!3d23.026022299999998!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x395e84faa5a36071%3A0x9af325a448f09478!2sTOPS%20Technologies!5e1!3m2!1sen!2sin!4v1738512983742!5m2!1sen!2sin"  allowFullScreen loading="lazy" referrerPolicy="no-referrer-when-downgrade" />

                   </div>
                   <div className='border' height={"200px"} width={"200px"} >

                   </div>
               </div>
           </div>
          <div className='d-flex gap-2 flex-wrap'>
              <div className='small-photos'> <img src={view.img4}></img></div>
              <div className='small-photos'> <img src={view.img5}></img></div>
              <div className='small-photos'> <img src={view.img6}></img></div>
              <div className='small-photos'> <img src={view.img7}></img></div>
              <div className='small-photos'> <img src={view.img8}></img></div>
          </div>
        </div>
      </div>




    </>
  )
}

export default View