import React from 'react'

function SecondContainer() {
  return (
   <>
    <div className='sec-container'>
       <h4>NEW</h4>
       <h2>Recent Games</h2>
       <div className='container2'>
        <div className='row2'>
            <div className='col2'>
                <div className='game1'>
                    <h4>NEW</h4>
                    <img src='https://themewagon.github.io/game-warrior/img/recent-game/1.jpg'></img>
                </div>
                <div className='game-info'>
                   <h5>Suspendisse ut justo tem por, rutrum</h5>
                   <p>
                   Lorem ipsum dolor sit amet, consectetur adipisc ing ipsum dolor sit amet, consectetur elit.
                   </p>
                   <span>3 Comments</span>
                </div>
            </div>
            <div className='col2'>
                <div className='game1'>
                    <h4 className='race'>RACING</h4>
                    <img src='https://themewagon.github.io/game-warrior/img/recent-game/2.jpg'></img>
                </div>
                <div className='game-info'>
                   <h5>Suspendisse ut justo tem por, rutrum</h5>
                   <p>
                   Lorem ipsum dolor sit amet, consectetur adipisc ing ipsum dolor sit amet, consectetur elit.
                   </p>
                   <span>3 Comments</span>
                </div>
            </div>
            <div className='col2'>
                <div className='game1'>
                    <h4 className='adven'>Adventure</h4>
                    <img src='https://themewagon.github.io/game-warrior/img/recent-game/3.jpg'></img>
                </div>
                <div className='game-info'>
                   <h5>Suspendisse ut justo tem por, rutrum</h5>
                   <p>
                   Lorem ipsum dolor sit amet, consectetur adipisc ing ipsum dolor sit amet, consectetur elit.
                   </p>
                   <span>3 Comments</span>
                </div>
            </div>
        </div>
       </div>
    </div>
   </>
  )
}

export default SecondContainer