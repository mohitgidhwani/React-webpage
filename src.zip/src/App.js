import logo from './logo.svg';
import './App.css';
import Header from './Header';
import Content from './Content';
import 'react-date-range/dist/styles.css'; // main style file
import 'react-date-range/dist/theme/default.css'; // theme css file
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import { useEffect, useState } from 'react';
import Hotels from './Hotels';
import View from './View';





function App() {

  const [hotels, setHotels] = useState([])
  const [filteredHotels, setFilteredHotels] = useState([])
  const [locationInput, setLocationInput] = useState('')

  useEffect(() => {
    fetch(`http://localhost:5000/hotel`)
      .then((res) => { return res.json() })
      .then((data) => {
        setHotels(data)
        setFilteredHotels(data)
      })
  }, [])

  const findhotel = (e) => {
    const value = e.target.value

    setLocationInput(value)

    const filtered = hotels.filter((hotel) => (
      hotel.location.toLowerCase().includes(value.toLowerCase())
    )
    )
    setFilteredHotels(filtered)
  }






  return (
    <div className="App">





      <BrowserRouter>
        <Header></Header>
        <Content fun={findhotel}></Content>
        
        <Routes>
          <Route path='/' element={<Hotels hook={filteredHotels}></Hotels>}></Route>
          <Route path='/view/:id' element={<View></View>}></Route>
        </Routes>
      </BrowserRouter>

    </div>
  );
}

export default App;
