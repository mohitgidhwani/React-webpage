import logo from './logo.svg';
import './App.css';
import Header from './Header'
import Hero from './Hero'
import FirstContainer from './FirstContainer';
import SecondContainer from './SecondContainer';
import ThirdContainer from './ThirdContainer';
import FourthContainer from './FourthContainer';
import RevieweContainer from './RevieweContainer';
import Footer from './Footer';


function App() {
  return (
    // <div className="App">
    //   <header className="App-header">
    //     <img src={logo} className="App-logo" alt="logo" />
    //     <p>
    //       Edit <code>src/App.js</code> and save to reload.
    //     </p>
    //     <a
    //       className="App-link"
    //       href="https://reactjs.org"
    //       target="_blank"
    //       rel="noopener noreferrer"
    //     >
    //       Learn React
    //     </a>
    //   </header>
    // </div>
    <>
    <Header></Header>
    <Hero></Hero>
    <FirstContainer></FirstContainer>
    <SecondContainer></SecondContainer>
    <ThirdContainer></ThirdContainer>
    {/* <FourthContainer></FourthContainer> */}
    <RevieweContainer></RevieweContainer>
    <Footer></Footer>
    
    
    </>
  );
}

export default App;
